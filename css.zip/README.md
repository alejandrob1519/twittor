# Chat de Héroes

Un cascarón de chat usando jQuery para PWAs